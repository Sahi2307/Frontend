document.getElementById('sign').addEventListener('submit', function(event) {
  event.preventDefault();

  let isValid = true;

  // Clear previous error messages
  document.querySelectorAll('.error-message').forEach(element => {
      element.textContent = '';
  });

  // Username validation
  const username = document.getElementById('name').value;
  if (username.length < 3 || username.length > 15) {
      isValid = false;
      document.getElementById('usernameError').textContent = '*Username must be between 3 and 15 characters.';
      usernameError.style.color = 'yellow';
      console.log('Username validation failed');
  }

  // Email validation
  const email = document.getElementById('mail').value;
  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (!emailPattern.test(email)) {
      isValid = false;
      document.getElementById('emailError').textContent = '*Enter a valid email address.';
      emailError.style.color = 'yellow';
      console.log('Email validation failed');
  }

  // Password validation
  const password = document.getElementById('password').value;
  if (password.length < 6) {
      isValid = false;
      document.getElementById('passwordError').textContent = '*Password must be at least 6 characters long.';
      passwordError.style.color = 'yellow';
      console.log('Password validation failed');
  }

  if (isValid) {
      // Form is valid, submit the form data (e.g., send it to the server)
      console.log('Form is valid');
      alert('Form submitted successfully!');
      this.submit();
  } else {
      console.log('Form is not valid');
  }
document.getElementById("name").value=""  
document.getElementById("mail").value=""
document.getElementById("password").value=""
});
