const apiKey = 'bd85531c23d67007c703b50347f16663'; 
const fetchWeatherData = async (cityName) => {
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${apiKey}`;

    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error(`Error fetching weather data: ${response.status}`);
        }
        const weatherData = await response.json();
        updateWeatherDisplay(weatherData);
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('data').textContent = 'Error retrieving weather data.';
    }
};

const updateWeatherDisplay = (data) => {
    const city = data.name;
    const temp = Math.round(data.main.temp - 273.15); // Convert Kelvin to Celsius
    const description = data.weather[0].description;

    const weatherInfo = `
        <h2>Weather in ${city}</h2>
        <p>Temperature: ${temp} °C</p>
        <p>Status: ${description}</p>
    `;

    document.getElementById('data').innerHTML = weatherInfo;
};

const getWeatherButton = document.getElementById('button');
const cityInput = document.getElementById('city');

getWeatherButton.addEventListener('click', () => {
    const cityName = city.value.trim(); // Trim leading/trailing whitespace
    if (cityName) {
        fetchWeatherData(cityName);
    } else {
        alert('Please enter a city name.');
    }
});
